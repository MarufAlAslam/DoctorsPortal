$('.slider').slick({
    dots: true,
    infinite: true,
    speed: 300,
    slidesToShow: 5,
    slidesToScroll: 1,
    dots:false,
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 4,
          slidesToScroll: 1,
          infinite: true,
          dots: true
        }
      },
      {
        breakpoint: 600,
        settings: {
          slidesToShow: 3,
          slidesToScroll: 1
        }
      },
      {
        breakpoint: 480,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1
        }
      }
      // You can unslick at a given breakpoint now by adding:
      // settings: "unslick"
      // instead of a settings object
    ]
  });


  $('#next1').click(function(event){
      event.preventDefault()
      $('.step1').hide()
      $('.step2').show()
  })

  $('#next2').click(function(event){
    event.preventDefault()
    $('.step2').hide()
    $('.step3').show()
})

$('#next3').click(function(event){
    event.preventDefault()
    $('.step3').hide()
    $('.step4').show()
})

$('#next4').click(function(event){
    event.preventDefault()
    $('.step4').hide()
    $('.step5').show()
})

$('#card1').click(function(event){
    event.preventDefault()
    $('#card1 .card').addClass("activeCard1")
    $('#card2 .card').removeClass("activeCard2")
    $('#card3 .card').removeClass("activeCard3")
    $('#next3').attr("disabled",false)
})

$('#card2').click(function(event){
    event.preventDefault()
    $('#card1 .card').removeClass("activeCard1")
    $('#card2 .card').addClass("activeCard2")
    $('#card3 .card').removeClass("activeCard3")
    $('#next3').attr("disabled",false)
})

$('#card3').click(function(event){
    event.preventDefault()
    $('#card1 .card').removeClass("activeCard1")
    $('#card2 .card').removeClass("activeCard2")
    $('#card3 .card').addClass("activeCard3")
    $('#next3').attr("disabled",false)
})